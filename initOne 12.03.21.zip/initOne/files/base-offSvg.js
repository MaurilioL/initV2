

// ---------------------------------
// inclusão de SVS dentro do arquivo
// ---------------------------------

// retorna todos os svg.preSvg do DOM em forma de Arrey
function getPreSvgDOM() {
    const preSvg = document.querySelector('svg.preSvg')
    return preSvg
}

// retorna o link para o SVG indicado no HTML
function getUrlSVG(preSvg) {
    let tipo
    let nome
    let caminhoDoSvg

    tipo = preSvg.attributes.icon_tipo.value
    nome = preSvg.attributes.icon_nome.value
    caminhoDoSvg = urlMatriz + 'files/icon' + tipo + nome

    return caminhoDoSvg
}

// colocando o SVG dentro do HTML

function name(params) {
    
    for(let i = 0; i < preSvg.length; i++){
        // console.log('indice: ' + i);
        // console.log(myArray[i]);

    }

}