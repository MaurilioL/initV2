**_os ícones foram gerado de forma automática através da imagem “logoInitOne[4169x3395]mascote” pelo site: https://realfavicongenerator.net/_**


_segue abaixo o README que o https://realfavicongenerator.net/ disponibilizou_


# Your Favicon Package

This package was generated with [RealFaviconGenerator](https://realfavicongenerator.net/) [v0.16](https://realfavicongenerator.net/change_log#v0.16)

## Install instructions

To install this package:

Extract this package in <code>&lt;web site&gt;/files/icon/iconInitOne/</code>. If your site is <code>http://www.example.com</code>, you should be able to access a file named <code>http://www.example.com/files/icon/iconInitOne/favicon.ico</code>.

Insert the following code in the `head` section of your pages:

    <link rel="apple-touch-icon" sizes="180x180" href="files/icon/iconInitOne/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="files/icon/iconInitOne/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="192x192" href="files/icon/iconInitOne/android-chrome-192x192.png">
    <link rel="icon" type="image/png" sizes="16x16" href="files/icon/iconInitOne/favicon-16x16.png">
    <link rel="manifest" href="files/icon/iconInitOne/site.webmanifest">
    <link rel="mask-icon" href="files/icon/iconInitOne/safari-pinned-tab.svg" color="#309994">
    <link rel="shortcut icon" href="files/icon/iconInitOne/favicon.ico">
    <meta name="msapplication-TileColor" content="#219191">
    <meta name="msapplication-config" content="files/icon/iconInitOne/browserconfig.xml">
    <meta name="theme-color" content="#505050">

*Optional* - Check your favicon with the [favicon checker](https://realfavicongenerator.net/favicon_checker)