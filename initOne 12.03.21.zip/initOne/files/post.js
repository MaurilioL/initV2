/*
================================
    criando sumario
================================
*/

function getTitulos() {

    const Hx = '#corpo>h2, #corpo>h3, #corpo>h4, #corpo>h5, #corpo>h6'
    const grupoTitulos = document.querySelectorAll(Hx)

    let titulos = []

    for (let i = 0; i < grupoTitulos.length; i++) {
        const titulo = {}
        const conteudoDom = grupoTitulos[i];
        titulo.nvl = parseInt(conteudoDom.localName.substr(1, 1), 10)
        titulo.txt = conteudoDom.innerText
        titulo.id = 'tituloNun' + (i + 1)
        // titulo.id = conteudoDom.localName + '-' + (i + 1) + conteudoDom.innerText.replace(/\W/g, '')
        titulo.dom = conteudoDom
        titulos.push(titulo)

        // colocando o ID nos titulos
        conteudoDom.id = titulo.id
    }

    return (titulos)

    /* return: [ {
        nvl = qual é o nivel do H
        txt = qual é o texto do titulo
        id = o ID que referencia a esse titulo
        dom = aponto para o titulo dentro do DOM
    }] */

}

function criarLinha(titulo) {
    //criando o link <a>
    const a = document.createElement('a')
    a.href = '#' + titulo.id
    a.innerHTML = titulo.txt

    // adicioanndo o item <li>
    const li = document.createElement('li')
    li.setAttribute('nvl', titulo.nvl)
    li.id = 'li' + 'titulo.id'

    //concatenando os elementos
    // li > a 
    li.appendChild(a)

    return li
}

function nvlDentro(nvlAtual) {
    const criandoOl = document.createElement('ol')
    criandoOl.setAttribute('nvl', nvlAtual + 1)
    return criandoOl
}

function getSumario(titulos, tabela) {
    let olBase = document.createElement('ol')
    olBase.setAttribute('nvl', 2)
    tabela.appendChild(olBase)
    let nvlAtual = 2

    for (let i = 0; i < titulos.length; i++) {
        const titulo = titulos[i];

        if (titulo.nvl == nvlAtual) {

            // adicioanndo a linha
            const li = criarLinha(titulo)

            //concatenando os elementos
            // ol > (li > a)
            olBase.appendChild(li)

        } else if (titulo.nvl > nvlAtual) {
            while (titulo.nvl > nvlAtual) {
                // criando um <ol> para entrar um lvl
                const ol = nvlDentro(nvlAtual)

                //concatenando os elementos
                // ol > ol
                olBase.appendChild(ol)

                // entrando um nvl a dentro
                olBase = olBase.lastElementChild
                nvlAtual = parseInt(olBase.getAttribute('nvl'))
            }

            // adicioanndo a linha desse lvl
            const li = criarLinha(titulo)

            //concatenando os elementos
            // ol > (li > a)
            olBase.appendChild(li)

        } else if (titulo.nvl < nvlAtual) {

            // voltando os nvl nescessarios
            while (titulo.nvl < nvlAtual) {
                olBase = olBase.parentElement
                nvlAtual = parseInt(olBase.getAttribute('nvl'))
            }

            // adicioanndo a linha desse lvl
            const li = criarLinha(titulo)

            //concatenando os elementos
            // ol > (li > a)
            olBase.appendChild(li)

        } else {
            console.log('===================================')
            console.log('"titulo.nvl" e "nvlAtual"')
            console.log('ñ estão interagindo corretametne')
            console.log('titulo.nvl: ', titulo.nvl)
            console.log('nvlAtual :', nvlAtual)
            console.log(olBase)
            console.log('===================================')
        }
    }
}

function getSumarioBox(boxNoDOM) {

    /*
    <details id="sumario" aria-label="Estrutura de tópicos do artigo">
        <summary id="sumario-titulo">Sumário</summary>
        <nav id="sumario-lista" role="navigation">
            <!-- criada pelo js -->
        </nav>
    </details>
    */

    const details = document.createElement('details')
    details.id = 'sumario'
    details.setAttribute('aria-label', 'Estrutura em tópicos do artigo')

    const summary = document.createElement('summary')
    summary.id = 'sumario-titulo'
    summary.innerText = 'Sumário'

    const nav = document.createElement('nav')
    nav.id = 'sumario-lista'
    nav.classList.add('scrollbar')
    nav.setAttribute('role', 'navigation')

    // concatenando os itens
    // details > summary
    details.appendChild(summary)
    //details > nav
    details.appendChild(nav)
    // colocando no html
    boxNoDOM.appendChild(details)
}