// salvando a Url da pagina
const urlMatriz = () => document.getElementById('mastroLogo').href