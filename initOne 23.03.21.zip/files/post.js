const corpoDOM = document.getElementById('corpo')

// ==============================================
// ------------------ sumario ------------------
// ==============================================
{
    // -> funçoes para criar o sumario
    {
        function getTitulos() {

            const Hx = 'h2, h3, h4, h5, h6'
            const grupoTitulos = corpoDOM.querySelectorAll(Hx)

            let titulos = []

            for (let i = 0; i < grupoTitulos.length; i++) {
                const titulo = {}
                const conteudoDom = grupoTitulos[i];
                titulo.nvl = parseInt(conteudoDom.localName.substr(1, 1), 10)
                titulo.txt = conteudoDom.innerText
                titulo.id = 'tituloNun' + (i + 1)
                titulo.dom = conteudoDom
                titulos.push(titulo)

                // colocando o ID nos titulos
                conteudoDom.id = titulo.id
            }

            return (titulos)

            /* return: [ {
                nvl = qual é o nivel do H
                txt = qual é o texto do titulo
                id = o ID que referencia a esse titulo
                dom = aponto para o titulo dentro do DOM
            }] */

        }

        function criarLinha(titulo) {
            //criando o link <a>
            const a = document.createElement('a')
            a.href = '#' + titulo.id
            a.innerHTML = titulo.txt

            // adicioanndo o item <li>
            const li = document.createElement('li')
            li.setAttribute('nvl', titulo.nvl)
            li.id = 'li' + 'titulo.id'

            //concatenando os elementos [li > a ]
            li.appendChild(a)

            return li
        }

        function nvlDentro(nvlAtual) {
            const criandoOl = document.createElement('ol')
            criandoOl.setAttribute('nvl', nvlAtual + 1)
            return criandoOl
        }

        function getSumario(titulos, tabela) {
            let olBase = document.createElement('ol')
            olBase.setAttribute('nvl', 2)
            tabela.appendChild(olBase)
            let nvlAtual = 2

            for (let i = 0; i < titulos.length; i++) {
                const titulo = titulos[i];

                if (titulo.nvl == nvlAtual) {

                    // adicioanndo a linha
                    const li = criarLinha(titulo)

                    //concatenando os elementos [ol > (li > a)]
                    olBase.appendChild(li)

                } else if (titulo.nvl > nvlAtual) {
                    while (titulo.nvl > nvlAtual) {
                        // criando um <ol> para entrar um lvl
                        const ol = nvlDentro(nvlAtual)

                        //concatenando os elementos [ol > ol]
                        olBase.appendChild(ol)

                        // entrando um nvl a dentro
                        olBase = olBase.lastElementChild
                        nvlAtual = parseInt(olBase.getAttribute('nvl'))
                    }

                    // adicioanndo a linha desse lvl
                    const li = criarLinha(titulo)

                    //concatenando os elementos [ol > (li > a)]
                    olBase.appendChild(li)

                } else if (titulo.nvl < nvlAtual) {

                    // voltando os nvl nescessarios
                    while (titulo.nvl < nvlAtual) {
                        olBase = olBase.parentElement
                        nvlAtual = parseInt(olBase.getAttribute('nvl'))
                    }

                    // adicioanndo a linha desse lvl
                    const li = criarLinha(titulo)

                    //concatenando os elementos [ol > (li > a)]
                    olBase.appendChild(li)

                } else {
                    console.log('"titulo.nvl" e "nvlAtual" ñ estão interagindo corretametne')
                }
            }
        }

        function getSumarioBox(boxNoDOM) {

            /*
            <details id="sumario" aria-label="Estrutura de tópicos do artigo">
                <summary id="sumario-titulo">Sumário</summary>
                <nav id="sumario-lista" role="navigation">
                    <!-- criada pelo js -->
                </nav>
            </details>
            */

            const details = document.createElement('details')
            details.id = 'sumario'
            details.setAttribute('aria-label', 'Estrutura em tópicos do artigo')

            const summary = document.createElement('summary')
            summary.id = 'sumario-titulo'
            summary.innerText = 'Sumário'

            const nav = document.createElement('nav')
            nav.id = 'sumario-lista'
            nav.classList.add('scrollbar')
            nav.setAttribute('role', 'navigation')

            // concatenando os itens [details > summary]
            details.appendChild(summary)
            // [details > nav]
            details.appendChild(nav)
            // colocando no html
            boxNoDOM.appendChild(details)
        }
    }

    // =================
    // criando o Sumario
    // =================

    // pegando o tamanho para referencias:
    const LarguraJanela = window.innerWidth
    const AlturaJanela = window.innerHeight
    const AlturaCardPerfil = document.getElementById('cardPerfilBox').offsetHeight
    const AlturaConteudo = corpoDOM.offsetHeight

    function getSumarioBoxDOM() {
        if (LarguraJanela >= 992) {
            return document.getElementById('sumarioBox-coluna')
        } else {
            return document.getElementById('sumarioBox-corpo')
        }
    }

    const sumarioBoxDOM = getSumarioBoxDOM()
    getSumarioBox(sumarioBoxDOM) // preparando o local do Sumario
    const sumarioDetailsDOM = sumarioBoxDOM.children[0]
    const sumarioListaDOM = sumarioDetailsDOM.children[1]

    if (LarguraJanela >= 992) {
        if (AlturaConteudo > AlturaJanela + AlturaCardPerfil) {
            sumarioDetailsDOM.setAttribute('open', 'true') // deixando aberto
        } else {
            sumarioDetailsDOM.setAttribute('close', 'true') // deixando fechado
        }
    } else {
        sumarioDetailsDOM.setAttribute('close', 'true') // telas menores sempre é fechado
    }

    // colocando a lista dos titulos/links dentro do sumario
    getSumario(getTitulos(), sumarioListaDOM) //onde a magia acontece
}


// ==============================================
// Listas de Definição .compacta e .compactaLonga
// ==============================================
{
    // -> funçoes para as Listas de Definição
    {
        function mapeandoLista(lista) {
            const filhos = lista.children
            const dtMapa = []

            // um volta por cada item da tabela
            for (let i = 0; i < filhos.length; i++) {
                const filho = filhos[i];
                const tegHTML = filho.localName

                if (tegHTML == 'dt') {
                    // criara um novo objeto no inicio do dtMapa
                    let dtDados = {}
                    dtDados.dom = filho,
                        dtDados.ddContador = 0

                    dtMapa.unshift(dtDados)

                } else if (tegHTML == 'dd') {
                    // vai somando dentro do abjeto quantos dd tem
                    if (dtMapa[0] != undefined) {
                        dtMapa[0].ddContador++;
                    }
                }
            }
            return dtMapa
        }

        // mapeando o que tem nas Listas de Definições
        function mapaListDefinicao(listas) {
            let listasMapa = []

            for (let i = 0; i < listas.length; i++) {
                const lista = listas[i];
                const dtGrupo = mapeandoLista(lista)

                for (let i = 0; i < dtGrupo.length; i++) {
                    const dt = dtGrupo[i];
                    listasMapa.push(dt)
                }
            }
            return listasMapa
        }

        function formatandoListasDefinicao(listas) {
            for (let i = 0; i < listas.length; i++) {
                const lista = listas[i];

                if (lista.ddContador > 0) {
                    lista.dom.style['grid-row'] = 'span ' + lista.ddContador
                }
            }
        }
    }

    // ===============================
    // editando as Listas de Definição
    // ===============================
    const listaDefinicaoDOM = corpoDOM.querySelectorAll(['dl.listaCompacta', 'dl.listaCompactaLonga'])

    //verificando se temos listas descritivas
    if (listaDefinicaoDOM.length > 0) {
        formatandoListasDefinicao(mapaListDefinicao(listaDefinicaoDOM))
    }
}

// ==============================================
// -------- adicionando link para as img --------
// ==============================================
{
    {
        function imgMapa(imgsDOM) {
            imgMap = []
            for (let i = 0; i < imgsDOM.length; i++) {
                const imgDOM = imgsDOM[i];
                // saida paiIMg + caminho da img (src) + descrição img (alt) + titulo da img (title)

                const paiImg = imgDOM.parentNode

                const newImg = document.createElement('img')
                newImg.classList = imgDOM.classList
                newImg.src = imgDOM.src
                newImg.alt = imgDOM.alt
                newImg.title = imgDOM.title

                const bloco = {
                    pai: paiImg,
                    img: newImg,
                }
                imgMap.push(bloco)
            }
            return imgMap
        }

        function formatandoImg(gImgs) {
            for (let i = 0; i < gImgs.length; i++) {
                const img = gImgs[i].img
                const pai = gImgs[i].pai

                const a = document.createElement('a') // criando o link <a>
                a.target = '_blank' // para o link abrir em uma nova janela
                a.href = img.src // link da img

                a.appendChild(img) // adicionando a img dentro do link
                pai.removeChild(pai.childNodes[0]) // removendo a img antiga do DOM
                pai.appendChild(a); // colocando a img nova com o link dentro do DOM
            }
        }
    }

    const imgDOM = corpoDOM.getElementsByTagName('img')

    if (imgDOM.length > 0) {
        formatandoImg(imgMapa(imgDOM))
        
    }
}