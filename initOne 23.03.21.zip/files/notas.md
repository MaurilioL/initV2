

# algumas cores:

- cores para ver
    - #00B388
    - #16a085
    - rgb(0, 128, 128) -> teal
    - rgb(144, 185, 221) -> azul bem fraquinho




<!--
    ordem dos link
    Visited
    Focus
    Hover
    Active
-->